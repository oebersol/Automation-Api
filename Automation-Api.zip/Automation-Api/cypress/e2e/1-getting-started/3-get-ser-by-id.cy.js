const userUrl = 'https://serverest.dev/usuarios';

describe("Teste de busca de usuários", () => {
  it("Teste de Requisição GET", () => {
    cy.request({
      method: "GET",
      url: userUrl,
    }).as("response");

    cy.get("@response").should((response) => {
      expect(response.status).to.eq(200);
      expect(response.body.usuarios).to.be.an('array').that.is.not.empty;
    });
  });
});

